#!/bin/bash

flex calc.l
yacc -d calc.y
g++ -c -w lex.yy.c y.tab.c
g++ -o mycalc y.tab.o lex.yy.o
./mycalc<in.txt
