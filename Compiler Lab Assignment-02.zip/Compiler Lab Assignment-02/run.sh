flex -t a.l>a.c
g++ -c -o a.o a.c
g++ -o a a.o -ll
./a<in.txt
